<?php
error_reporting(0);
include "config.php";
session_start();
if(!empty($_SESSION['user'])){
    header("location: /profile.php");
}
    session_start();
    $username = $_POST['username'];
    $password = $_POST['password'];
    if(!empty($username)&&!empty($password)){
        if($username==='admin')
            {
                $sql = "select password from member";
                $result = $mysqli->query($sql);
                $row = $result->fetch_row();
                if($row[0]===md5($password)){
                    $_SESSION['user']='admin';
                    $_SESSION['admin']=1;
                    header("location: /profile.php");
                }
                else{
                    echo "<script>alert('nononon,admin password not right')</script>";
                }
            }
        else{
            $_SESSION['user']='guest';
            $_SESSION['admin']=0;
            header("location: /profile.php");
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>profile</title>
    <link href="static/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="static/bootstrap.min.js"></script>
    <script src="static/jquery.min.js"></script>
    <style>
        .fakeimg {
            height: 200px;
            background: #aaa;
        }
    </style>
</head>
<!------ Include the above in your HEAD tag ---------->
<body>
    <div id="login">
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-19">
                        <form id="login-form" class="form" action="index.php" method="post">
                            <h3 class="text-center text-info">Login</h3>
                            <div class="form-group">
                                <label for="username" class="text-info">Username:</label><br>
                                <input type="text" name="username" id="username" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info">Password:</label><br>
                                <input type="password" name="password" id="password" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
