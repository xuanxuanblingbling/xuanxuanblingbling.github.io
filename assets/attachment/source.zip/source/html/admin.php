<?php
include "profile.php";
session_start();
if(empty($_SESSION['user'])){
    header("location: index.php");
}
if($_SESSION['admin']==1){
    phpinfo();
}
else{
    print <<<EOT
<div class="row">
  <div class="col-md-6 col-md-offset-4">You are not admin!!!!</div>
</div>
EOT;

}