# Favourite Architecture

## flag0

It's a RE challenge.

## flag1

Read `/home/pwn/flag`.

## flag2

Execute `/readflag2`.

