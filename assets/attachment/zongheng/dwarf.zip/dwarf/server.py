import os
import string
import random
from backports import tempfile
import shutil
import subprocess
import base64
import sys

CODE_TPL = """
#include <iostream>
#include <memory>
#include <vector>
#include <map>

#define REGISTER(classname) \\
private: \\
   static const CreatorImpl<classname> creator;

#define REGISTERIMPL(classname) \\
   const CreatorImpl<classname> classname::creator(#classname);

class Drawf {{
    public:
        std::string name;
        virtual void print_info(){{}};
        virtual void set_ele(unsigned int size, unsigned int val){{}};
        void set_name(const std::string& _name) {{name = _name;}};
}};

class Creator
{{
public:
   virtual Drawf* create() = 0;
   Creator(const std::string& classname);
}};

class Factory
{{
public:
   static Drawf* create(const std::string& classname);
   static void registerit(const std::string& classname, Creator* creator);
private:
   static std::map<std::string, Creator*>& get_table();
}};

Factory factory;

Creator::Creator(const std::string& classname) {{
    Factory::registerit(classname, this);
}}

template <class T>
class CreatorImpl : public Creator
{{
public:
    CreatorImpl(const std::string& classname): Creator(classname) {{}}
    virtual Drawf* create() {{ return new T; }}
}};


void Factory::registerit(const std::string& classname, Creator* creator)
{{
   get_table()[classname] = creator;
}}

Drawf* Factory::create(const std::string& classname)
{{
   std::map<std::string, Creator*>::iterator i;
   i = get_table().find(classname);
   if (i != get_table().end())
      return i->second->create();
   else
      return (Drawf*)NULL;
}}

std::map<std::string, Creator*>& Factory::get_table() {{
    static std::map<std::string, Creator*> table;
    return table;
}}

{classes_info}

typedef std::shared_ptr<Drawf> dwarf_t;

void init() {{
   	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
}}

void Create(std::vector<dwarf_t> &list) {{
    std::string name, input_name;
    std::cout << "Which type? ";
    std::cin >> input_name;
    auto t = factory.create(input_name);
    if (t) {{
        std::cout << "name: ";
        std::cin >> input_name;
        t->set_name(input_name);
        list.push_back(dwarf_t(t));
    }} else {{
        std::cout << "Invalid." << std::endl;
    }}
}}

dwarf_t get_dwarf(std::vector<dwarf_t> &list) {{
    std::string input_name;
    std::cout << "name? ";
    std::cin >> input_name; 
    for (auto it = list.begin(); it != list.end(); ++it) {{
        if ((*it)->name == input_name) {{
            std::cout << (*it)->name << std::endl;
            return *it;
        }}
    }}
    std::cout << "Not found." << std::endl;
    return nullptr;
}}

void Get(std::vector<dwarf_t> &list) {{
    dwarf_t tmp = get_dwarf(list);
    if (tmp){{
        tmp->print_info();
    }} else {{
        puts("Oops");
    }}
}}

void Delete(std::vector<dwarf_t> &list) {{
    std::string input_name;
    std::cout << "name? ";
    std::cin >> input_name;
    for (auto it = list.begin(); it != list.end(); ++it) {{
        if ((*it)->name == input_name) {{
            list.erase(it);
            return;
        }}
    }}
    std::cout << "Not found." << std::endl;
}}

void Clone(std::vector<dwarf_t> &list) {{
    dwarf_t target = get_dwarf(list);
    if (target) {{
        list.push_back(dwarf_t(target.get()));
    }}
}}

void View(std::vector<dwarf_t> &list) {{
    for (auto it = list.begin(); it != list.end(); ++it) {{
        std::cout << (*it)->name << "->";
    }}
    std::cout << "END" << std::endl;
}} 

void Set(std::vector<dwarf_t> &list) {{
    dwarf_t target = get_dwarf(list);
    unsigned int off, val;
    if (target) {{
        std::cout << "off val" << std::endl;
        std::cin >> off >> val;
        target->set_ele(off, val);
    }}
}}

int main() {{
    int choice;
    init();
    std::vector<dwarf_t> list;
    
    while (1) {{
        std::cout << "Choice: ";
        std::cin >> choice;
        switch(choice) {{
            case 1:
                Create(list);
                break;
            case 2:
                Get(list);
                break;
            case 3:
                Delete(list);
                break;
            case 4:
                Clone(list);
                break;
            case 5:
                Set(list);
                break;
            case 6:
                View(list);
                break;
            default:
                puts("Invalid.");
                break;
        }}
    }}
}}
"""
CLASS_TPL = """
class {name}: public Drawf {{
    public: 
        {name}();
        void print_info();
        void set_ele(unsigned int size, unsigned int val);
    private:
        {members}
    REGISTER({name})
}};

{name}::{name}() {{
    std::cout << "size:" << {vec_size} << std::endl;
    vec.resize({vec_size});
}}

REGISTERIMPL({name})

void {name}::set_ele(unsigned int size, unsigned int val) {{
    if (size < vec.size()) {{
        vec[size] = val;
    }} else {{
        puts("failed");
    }}
}}

void {name}::print_info() {{
    std::cout << a << std::endl;
}}
"""

def random_str_upper(n):
    return ''.join(random.choice(string.ascii_uppercase) for _ in range(n))

def random_str(n):
    return ''.join(random.choice(string.ascii_uppercase+string.ascii_lowercase) for _ in range(n))


vec = "std::vector<unsigned int> vec;"
a = "unsigned long long a;"
padding = "char padding[0x20];"

essential_member_map = {
    "std::vector<unsigned int> vec;" : 24,
    "unsigned long long a;" : 8,
}

padding_map = {
    'char {}[0x10];' : 16,
    'char {}[0x18];' : 24,
    'char {}[0x20];' : 32,
    'char {}[0x28];' : 40,
    'char {}[0x30];' : 48,
    'char {}[0x38];' : 56,
    'char {}[0x40];' : 64,
    'char {}[0x48];' : 72,
}
base_size = 40

def get_member_size(member_list):
    size = base_size
    for item in member_list:
        size += item[1]
    return size

def get_vec_off(member_list):
    size = base_size
    for item in member_list:
        if "vector" in item[0]:
            return size
        size += item[1]

def get_a_off(member_list):
    size = base_size
    for item in member_list:
        if "unsigned long long a" in item[0]:
            return size
        size += item[1]

def get_member_str(member_list):
    return "\n".join(map(lambda x: x[0], member_list))

def generate_class():
    member_list = []
    for item in essential_member_map.items():
        member_list.append(item)
    for i in range(0, random.randint(0, 6)):
        member_list.append(("unsigned long long {};".format(random_str(6)), 8))

    for i in range(0, random.randint(0, 6)):
        item = random.choice(padding_map.items())
        new_item = (item[0].format(random_str(6)), item[1])
        member_list.append(new_item)
    random.shuffle(member_list)

    return {
        'mem': get_member_str(member_list), 
        'a': get_a_off(member_list), 
        'vec': get_vec_off(member_list), 
        'size': get_member_size(member_list), 
        'vec_size': random.randint(0, 0x100) * 4
        }

def generate_bin(tmp_path):
    classes = []
    c1 = generate_class()
    classes.append(c1)

    c2 = None
    while True:
        t = generate_class()
        if t['a'] == c1['vec'] and t['size'] == c1['size']:
            c2 = t
            break
    classes.append(c2)

    c3 = None
    while True:
        t = generate_class()
        if t['size'] != c1['size']:
            c3 = t
            break
    c3['vec_size'] = c1['size'] / 4
    classes.append(c3)

    for i in range(10-3):
        classes.append(generate_class())

    classes_code_list = []
    for c in classes:
        classes_code_list.append(CLASS_TPL.format(name=random_str(6), vec_size=c['vec_size'], members=c['mem']))
    random.shuffle(classes_code_list)

    code = CODE_TPL.format(classes_info="".join(classes_code_list))
    f = open(tmp_path + "/main1.cc", "w")
    f.write(code)
    f.close()

    shutil.copy("/home/ctf/Makefile", tmp_path + "/Makefile")

    ret = subprocess.Popen(["make"], cwd=tmp_path, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ret.wait()

def dump_bin(tmp_path):
    ret = subprocess.Popen(["xz", "-kz", "main1"], cwd=tmp_path)
    ret.wait()
    print "Binary Dump:"
    print "="*15
    f = open(tmp_path+"/main1.xz", "r")
    data = base64.b64encode(f.read())
    print(data)
    print "="*15
    sys.stdout.flush()
    f.close()

def runner(tmp_path):
    bin_name = random_str(6)
    shutil.copy(tmp_path + "/main1", "/home/ctf/tmp/bin_"+bin_name)
    cmd = "/usr/sbin/chroot --userspec=1000:1000 /home/ctf /bin/timeout -s 9 60 /tmp/{}".format("bin_" + bin_name)
    ret=subprocess.Popen(cmd.split())
    ret.wait()

with tempfile.TemporaryDirectory() as tmpdirname:
    generate_bin(tmpdirname)
    dump_bin(tmpdirname)
    runner(tmpdirname)