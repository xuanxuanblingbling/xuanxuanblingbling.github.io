#!/bin/bash
timeout 300 ./qemu-system-x86_64 \
    -m 1G \
   	-initrd ./rootfs.cpio \
    -nographic \
    -kernel ./vmlinuz-5.0.5-generic \
    -L pc-bios/ \
    -append "priority=low console=ttyS0" \
    -monitor /dev/null \
    -device pipeline