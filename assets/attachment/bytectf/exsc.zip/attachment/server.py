#!/usr/bin/env python3 -u
import hashlib
import os
import random
import string
import sys
import subprocess
import tempfile
import uuid
import requests
import time

def download_file(url):
    try:
        download_dir = "download"
        if not os.path.isdir(download_dir):
            os.mkdir(download_dir)
        tmp_file = os.path.join(download_dir, time.strftime("%m-%d-%H:%M:%S", time.localtime())+str(uuid.uuid4()))
        f = requests.get(url)
        if not check(f.content.decode().strip()):
            return None
        with open(tmp_file, 'wb') as fp:
            fp.write(f.content)
        return tmp_file
    except:
        return None

def check(shellcode):
    if len(shellcode) >= 0x3000:
        return False
    for i in shellcode:
        if i not in string.ascii_lowercase and i not in string.ascii_uppercase and i not in string.digits:
            print(1)
            return False
    return True

print("Proof of work is required.")
prefix = "".join([random.choice(string.digits + string.ascii_letters) for i in range(10)])
resource = prefix + "ezsc"
bits = 28
cash = input("Enter one result of `hashcash -b {} -m -r {}` : ".format(bits, resource))
r = subprocess.run(["hashcash", "-d", "-c", "-b", str(bits), "-r", resource], input=cash.encode('utf-8'))
if r.returncode != 0:
    print("Nope!")
    exit()

print("Heard that you guys are good at alphanumeric shellcode")
url = input("Bragging is cheap, show me your shellcode url: ")
tmp_file = download_file(url)
if not tmp_file:
    print("Nope!")
time.sleep(0.5)
subprocess.run(["chroot", "/home/ctf", "/qemu-aarch64-static", "-L", "/aarch64-linux-gnu/", "/ezsc", tmp_file], stdout=sys.stdout, stderr=sys.stderr)
