# env
OS:ubuntu 18.04
Arch:aarch64
libc:2.27

