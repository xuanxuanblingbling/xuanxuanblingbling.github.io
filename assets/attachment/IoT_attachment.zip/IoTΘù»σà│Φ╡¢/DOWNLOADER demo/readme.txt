/etc/udev/rules.d/99-allwinnerdl.rules
